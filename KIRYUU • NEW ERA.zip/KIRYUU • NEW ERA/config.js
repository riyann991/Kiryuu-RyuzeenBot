global.owner = ['6287873446580']  
global.mods = ['6287873446580'] 
global.prems = ['6287873446580']
global.nameowner = 'Yann'
global.numberowner = '6287873446580' 
global.mail = 'support@tioprm.eu.org' 
global.gc = 'https://chat.whatsapp.com/FSgyaxhkYQgENfRSXOHe3o'
global.instagram = 'https://instagram.com/prm2.0'
global.wm = '© Made By Kiryuu Ryuzeen'
global.wait = '*Sedang di proses kak*...'
global.eror = 'Server Error kak'
global.stiker_wait = '⫹⫺ Stiker sedang dibuat...'
global.packname = 'Made With'
global.author = 'Yann'
global.autobio = true // Set true untuk mengaktifkan autobio
global.maxwarn = '10' // Peringatan maksimum

//INI WAJIB DI ISI!//
global.btc = 'dana' 
//Daftar terlebih dahulu https://api.botcahx.eu.org

//INI OPTIONAL BOLEH DI ISI BOLEH JUGA ENGGA//
global.lann = 'aquachan'
//Daftar https://api.betabotz.eu.org 

global.lol = 'adrianXfaiz'

global.APIs = {   
  btc: 'https://api.botcahx.eu.org', 
  lann: 'https://api.betabotz.eu.org', 
  lol: 'https://api.lolhuman.xyz'
}

global.APIKeys = { 
  'https://api.botcahx.eu.org': 'dana', 
  'https://api.betabotz.eu.org': 'aquachan', 
  'https://api.lolhuman.xyz': 'adrianXfaiz'
}

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})