const util = require("util");
const path = require("path");

let handler = async (m, { conn }) => {
    let kntl = `./vn/dosa.mp3`
	await conn.sendFile(m.chat, kntl, "dosa.mp3", null, m, true)
};
handler.customPrefix = /^(dosa|dosawoi|dosajir)$/i;
handler.command = new RegExp();

module.exports = handler;