let handler = async (m, { conn, args, text, usedPrefix: _p, command, isROwner }) => {

let pesan = `
*group berhasil di tutup tuan..*

━━━━━☐━━━━━
*Selamat Malam 🌝*

"waktunya istirahat jangan begadang.."
`
conn.groupSettingUpdate(m.chat, 'announcement')
conn.reply(m.chat, pesan, m)
}
handler.customPrefix = /^(😴)$/i 
handler.command = new RegExp
handler.botAdmin = true
handler.owner = true
handler.group = true
module.exports = handler