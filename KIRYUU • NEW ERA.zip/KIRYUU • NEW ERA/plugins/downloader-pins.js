const axios = require("axios");

const searchPins = async (keyword) => {
  try {
    const url = `https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${encodeURIComponent(
      keyword
    )}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${encodeURIComponent(
      keyword
    )}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D`;

    const response = await axios.get(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    });

    if (response.data && response.data.resource_response && response.data.resource_response.data) {
      const pins = response.data.resource_response.data.results || [];
      return pins.map((pin) => ({
        title: pin.title || "No Title",
        link: pin.link || "https://www.pinterest.com",
        image: pin.images.orig.url || "https://via.placeholder.com/500",
      }));
    } else {
      return `⚠️ Tidak ada hasil untuk "${keyword}".`;
    }
  } catch (error) {
    console.error("Terjadi kesalahan saat mencari pins:", error.message);
    throw new Error("Gagal mengambil hasil pencarian.");
  }
};

const handler = async (m, { conn, args }) => {
  if (!args.length) {
    m.reply("😏 masukin judul yang ingin dicari");
    return;
  }
  const keyword = args.join(" ");

  try {
    m.reply(`☺ Otw Cari "${keyword}"...`, m); 
    const pins = await searchPins(keyword);

    if (typeof pins === "string") {
      m.reply(pins, m);
    } else {
      const result = pins[0];

      if (!result) {
        m.reply(`😹 Tidak ada hasil untuk "${keyword}".`, m);
        return;
      }

      // Nama file sesuai
      const fileName = `${keyword.replace(/\s+/g, "_")}.png`;
      
      const customThumbnailUrl = result.image;
      const customImageUrlForDoc = result.image;
      const sentMessage = await conn.sendMessage(
        m.chat,
        {
          image: { url: result.image },
          caption: `_👉Ni hasil Dari "${keyword}"_\n©_YannCoder_`,
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363303246249933@newsletter", //ganti id ch kalian
              serverMessageId: 103,
              newsletterName: "© Yann coder",
            },
          },
          quoted: m
        }
      );

      await conn.sendMessage(
        m.chat,
        {
          document: { url: result.image },
          mimetype: "image/png",
          jpegThumbnail: await conn.resize(customImageUrlForDoc, 400, 400),
          fileName: fileName,
          caption: `📄 *Dokumen Gambar Hasil Pencarian untuk*: "${keyword}"`,
          contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363303246249933@newsletter", //ganti id ch kalian
              serverMessageId: 103,
              newsletterName: "© Yann coder",
            },
          },
          quoted: m
        }
      );
    }
  } catch (error) {
    console.error("Terjadi kesalahan di plugin Pinterest Search:", error.message);
    m.reply("⚠️ *Terjadi kesalahan saat mengambil data pencarian. Coba lagi nanti.*", m);
  }
};

handler.help = ["pins nama"];
handler.tags = ["downloader"];
handler.command = /^(pins)$/i;
handler.register = true

module.exports = handler;