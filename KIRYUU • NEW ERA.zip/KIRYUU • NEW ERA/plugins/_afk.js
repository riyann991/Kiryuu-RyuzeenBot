let handler = m => m
handler.before = m => {
  let user = global.db.data.users[m.sender]
  
  // Cek apakah pengguna sedang AFK
  if (user.afk > -1) {
    // Jika pesan menggunakan prefix, jangan set AFK selesai
    if (m.text.startsWith('.')) { // Ganti '!' dengan prefix yang kamu gunakan
      return true; // Biarkan pesan diproses lebih lanjut
    }

    m.reply(`
_kembali dari *AFK*_

👤 : user ⇩
> @${m.sender.split`@`[0]}
 
📝 : alasan afk ⇩
> ${user.afkReason ? 'setelah ' + user.afkReason : 'tanpa alasan'}

⏰ : lama waktu afk ⇩
> ${msToDate(new Date - user.afk)}
`.trim())
    
    // Set AFK selesai
    user.afk = -1
    user.afkReason = ''
  }

  // Cek jika ada yang men-tag pengguna yang AFK
  let jids = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
  for (let jid of jids) {
    let user = global.db.data.users[jid]
    if (!user) continue
    let afkTime = user.afk
    if (!afkTime || afkTime < 0) continue
    let reason = user.afkReason || ''
    m.reply(`
> *Jangan Tag Dia! ❌*

*dia sedang AFK 💤*

📝 : alasan afk ⇩
> ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}
⏰ : selama ⇩
> ${msToDate(new Date - afkTime)}
`.trim())
  }
  return true
}

module.exports = handler

function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}

function msToDate(ms) {
  let temp = ms
  let days = Math.floor(ms / (24 * 60 * 60 * 1000));
  let daysms = ms % (24 * 60 * 60 * 1000);
  let hours = Math.floor((daysms) / (60 * 60 * 1000));
  let hoursms = ms % (60 * 60 * 1000);
  let minutes = Math.floor((hoursms) / (60 * 1000));
  let minutesms = ms % (60 * 1000);
  let sec = Math.floor((minutesms) / (1000));
  return days + " Hari " + hours + " Jam " + minutes + " Menit " + sec + " detik ";
}