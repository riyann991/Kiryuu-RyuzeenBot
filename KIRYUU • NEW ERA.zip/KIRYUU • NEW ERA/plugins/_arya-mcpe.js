const handler = async (m, { conn, usedPrefix, command }) => {
  conn.reply(m.chat, `✩░▒▓▆▅▃▂▁𝐦𝐜𝐩𝐞 𝐝𝐨𝐰𝐧𝐥𝐨𝐚𝐝 ▁▂▃▅▆▓▒░✩  ${pickRandom(['https://mcpedl.org/uploads_files/05-12-2023/minecraft-1-20-50.apk spesifikasi versi 1.20 size 200MB', 'https://mcpedl.org/uploads_files/01-08-2024/minecraft-1-21-30-21.apk spesifikasi versi 1.21 size 223MB', 'https://mcpedl.org/uploads_files/03-11-2022/minecraft-1-19-41.apk spesifikasi versi 1.19 size 164MB', 'https://mcpedl.org/uploads_files/22-07-2022/minecraft-1-18-32.apk spesifikasi versi 1.18 size 150MB', 'https://mcpedl.org/uploads_files/25-04-2022/minecraft-1-17-41.apk spesifikasi versi 1.17 size 120MB', 'https://mcpedl.org/uploads_files/22-04-2021/minecraft-1-16-221-01-xbox-servers.apk spesifikasi versi 1.16 size 114MB', 'https://mcpedl.org/uploads_files/26-07-2020/minecraft-pe-1-15-0-54.apk spesifikasi versi 1.15 size 102MB', 'https://mcpedl.org/uploads_files/28-06-2020/minecraft-pe-1-14-60.apk spesifikasi 1.14 size 120MB', 'https://mcpedl.org/uploads_files/04-07-2020/minecraft-pe-1-13-1.apk spesifikasi 1.13 size 118MB', 'https://mcpedl.org/uploads_files/12-07-2020/minecraft-pe-1-12-1.apk spesifikasi 1.12 size 118MB', 'https://mcpedl.org/uploads_files/15-07-2020/minecraft-pe-1-11-4.apk spesifikasi 1.11 size 118MB', 'https://mcpedl.org/uploads_files/24-07-2020/minecraft-pe-1-10-0.apk spesifikasi 1.10 size 83MB', 'https://mcpedl.org/uploads_files/16-02-2022/minecraft-pe-0-5-0.apk spesifikasi kamu baru saja menemukan peradaban kuno alias Minecraft alpha 050 mamah aku takut -ditz', 'https://www.mediafire.com/file/bti2pqkhfpv0xtx/Minecraft_Alpha_v1.1.0-1_JalanTikus.jar/file ini berbeda karna ini adalah Minecraft alpha 1.0 💀 kalau anda tidak siap mental jangan download ntar mencekam mainnya dan bagi yang mau download silahkan saja saya tidak menjamin keselamatan jantung anda -ditz'])}`.trim(), m)
}

handler.help = ['dminecraft']
handler.tags = ['internet']
handler.command = /^dminecraft/i

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

module.exports = handler