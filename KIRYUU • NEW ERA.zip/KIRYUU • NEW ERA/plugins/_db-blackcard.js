async function before(m) {
    let user = global.db.data.users[m.sender];

    if (user.blcd === undefined) {
        user.blcd = false;
    }
    
    if (user.blcdsaldo === undefined) {
        user.blcdsaldo = 0;
    }
     
    if (user.blcdlevel === undefined) {
        user.blcdlevel = 0;
    }
    
    if (user.blcdkapasitas === undefined) {
        user.blcdkapasitas = 0;
    }
    
    if (user.blcdsaldo > user.blcdkapasitas) {
        user.blcdsaldo = user.blcdkapasitas;
    }

}

module.exports = { before };