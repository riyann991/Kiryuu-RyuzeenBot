let handler = async (m, { conn, command, text }) => {
conn.reply(m.chat, `ohayo gozaimasu 😘
`.trim(), m)
}
handler.customPrefix = /^(ohayo)$/i 
handler.command = new RegExp

module.exports = handler;