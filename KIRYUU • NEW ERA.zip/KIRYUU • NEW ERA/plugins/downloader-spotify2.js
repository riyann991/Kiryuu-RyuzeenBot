const axios = require('axios');
const { generateWAMessageFromContent, proto } = require('@adiwajshing/baileys');

const handler = async (m, { text }) => {
    if (!text) return m.reply('😅 Silakan masukkan judul lagu atau artis yang ingin dicari.');

    // Kirim pesan tunggu
    await m.reply('🔍 Tunggu sebentar, saya sedang mencari hasil untukmu...');

    try {
        // Tahap pertama: Mencari lagu di Spotify
        const searchResponse = await axios.get(`https://rest.cifumo.biz.id/api/downloader/spotify-search?q=${encodeURIComponent(text)}`);
        
        if (searchResponse.data && searchResponse.data.status && searchResponse.data.data.length > 0) {
            const track = searchResponse.data.data[0]; // Mengambil hasil pertama
            
            // Tahap kedua: Mendapatkan link download
            const dlResponse = await axios.get(`https://rest.cifumo.biz.id/api/downloader/spotify-dl?url=${encodeURIComponent(track.url)}`);

            if (dlResponse.data && dlResponse.data.status && dlResponse.data.data) {
                const downloadData = dlResponse.data.data;
                
                let msgs = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2,
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: `🎵 *Judul:* ${downloadData.title}\n🎤 *Artis:* ${downloadData.artis}\n🕒 *Durasi:* ${Math.floor(downloadData.durasi / 60000)}:${((downloadData.durasi % 60000) / 1000).toFixed(0)} menit\n🔗 *Download:* [Klik disini](${downloadData.download})`,
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: "© YueBot",
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            name: "cta_copy",
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "⚙️Url Download",
                                                copy_code: `${downloadData.download}`
                                            })
                                        },
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "🎧Download Audio",
                                                id: `.get ${downloadData.download}`,
                                            }),
                                        },
                                    ],
                                }),
                            }),
                        },
                    },
                }, {});
                
                await conn.relayMessage(m.key.remoteJid, msgs.message, {
                    messageId: m.key.id,
                });
            } else {
                m.reply('😔 Tidak dapat mengunduh lagu dari URL tersebut.');
            }
        } else {
            m.reply('😔 Tidak ditemukan hasil untuk pencarian tersebut.');
        }
    } catch (error) {
        m.reply('😓 Gagal mengambil data, coba lagi nanti.');
    }
};

handler.help = ['spotify2'];
handler.tags = ['downloader'];
handler.command = /^(spotify2)$/i;

module.exports = handler;