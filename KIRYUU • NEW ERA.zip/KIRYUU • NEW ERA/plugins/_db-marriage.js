async function before(m) {
    let user = global.db.data.users[m.sender];

    if (user.menikah === 0) {
        user.menikah = '';
    }
    
}

module.exports = { before };