const fs = require("fs");
const chara = require("../lib/bluearchive.json");

let handler = async (m, { conn }) => {
  //let archive = JSON.parse(fs.readFileSync('./lib/bluearchive.json'))
  let hasil = pickRandom(chara);
  let deks = `
*Info Characters*
----------------------
_👤Nama : ${hasil.character.name}_
🍁Umur : ${hasil.info.age}
⭐Birthday : ${hasil.info.birthDate}
📈Tinggi : ${hasil.info.height}
📖Sekolah : ${hasil.info.school}
☘️Klub : ${hasil.info.club}
🎯Profile : ${hasil.character.profile}
--------------------------
*Stats*
_⚔️Attack level 1 : ${hasil.stat.attackLevel1}_
⚔️Attack level 100 : ${hasil.stat.attackLevel100}
♻️Max Hp Level 1 : ${hasil.stat.maxHPLevel1}
♻️Max Hp Level 100 : ${hasil.stat.maxHPLevel100}
🛡Devense level 1 : ${hasil.stat.defenseLevel1}
🛡Devense level 100 : ${hasil.stat.defenseLevel100}
💚Heal power level 1 : ${hasil.stat.healPowerLevel1}
💚Heal power level 100 : ${hasil.stat.healPowerLevel100}
🪓Def penetrate level 1: ${hasil.stat.defPenetrateLevel1}
🪓Def penetrate level 100 : ${hasil.stat.defPenetrateLevel100}
🔫Ammo count : ${hasil.stat.ammoCount}
🔫Ammo cost : ${hasil.stat.ammoCost}
🔭Range : ${hasil.stat.range}
🌱Move speed : ${hasil.stat.moveSpeed}
❤️‍🩹Street mood : ${hasil.stat.streetMood}
📌Out door mood : ${hasil.stat.outdoorMood}
🛢Indoor mood : ${hasil.stat.indoorMood}
--------------------------
`;
  conn.sendMessage(m.chat, {
    text: deks,
    contextInfo: {
      mentionedJid: [m.sender],
      forwardingScore: 9999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "", //Channel jid
        serverMessageId: 20,
        newsletterName: "" //Channel jid
      },
      externalAdReply: {
        title: `Nama : ${hasil.character.name}`,
        body: `Birthday : ${hasil.info.birthDate}`,
        thumbnailUrl: hasil.image.icon,
        sourceUrl: "",
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: m }).catch((err) => reply('_⛩️Maaf terjadi Kesalahan!_'));
}

handler.help = ['charaba'];
handler.tags = ['info'];
handler.command = /^charabluearchive|charaba$/i;

module.exports = handler;

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}