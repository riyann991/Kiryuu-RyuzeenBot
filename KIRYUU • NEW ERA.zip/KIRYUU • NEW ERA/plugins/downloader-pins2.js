const handler = async (m, { conn, text }) => {
  if (!text) {
    return conn.sendMessage(m.chat, { text: '🔍 *Masukkan Query Untu Search Pinterest*' }, { quoted: m });
  }

  try {
    const apiUrl = `https://mannoffc-x.hf.space/pinterest?s=${encodeURIComponent(text)}`;
    const currentDate = new Date();
    const date = currentDate.getDate();
    const month = currentDate.getMonth() + 1;
    const year = currentDate.getFullYear();
    const formattedDate = `${date < 10 ? '0' : ''}${date}/${month < 10 ? '0' : ''}${month}/${year}`;

    const caption = `
✨ *Pinterest Pencarian Results* ✨   
🔎 *Search Term*: _${text}_
🖼️ *Ini Dia Hasil Pinterest, Sesuai Query*
📅 *Date*: _${formattedDate}_
📌 *Follow Ch kiryuu*!
`;

    const fkontak = {
      "key": {
        "participants": "0@s.whatsapp.net",
        "remoteJid": "status@broadcast",
        "fromMe": false,
        "id": "Halo"
      },
      "message": {
        "contactMessage": {
          "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
        }
      },
      "participant": "0@s.whatsapp.net"
    };

    const messageOptions = {
      image: { url: apiUrl },
      caption: caption,
      contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          "newsletterJid": "120363303246249933@newsletter",
          "serverMessageId": null,
          "newsletterName": formattedDate
        }
      }
    };

    if (m.quoted) {
      await conn.sendMessage(m.chat, messageOptions, { quoted: m.quoted });
    } else {
      await conn.sendMessage(m.chat, messageOptions, { quoted: fkontak });
    }

  } catch (error) {
    console.error('Error mengambil Pinterest image:', error);
    return conn.sendMessage(m.chat, { text: '⚠️Skill Isue, alias error.*' }, { quoted: fkontak });
  }
};

handler.help = ['pins2'];
handler.tags = ['downloader'];
handler.command = /^pins2$|^pinst$/i;

module.exports = handler;