const util = require("util");
const path = require("path");

let handler = async (m, { conn }) => {
    let kntl = `./src/vn/dame.mp3`
	await conn.sendFile(m.chat, kntl, "dame.mp3", null, m, true)
};
handler.customPrefix = /^(dame|dameyo|damedame)$/i;
handler.command = new RegExp();

module.exports = handler;