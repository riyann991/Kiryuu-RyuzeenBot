const axios = require('axios');
const cheerio = require('cheerio');

const handler = async (m, { conn }) => {
  try {
    const malUrl = 'https://myanimelist.net/topanime.php';
    const response = await axios.get(malUrl);
    const $ = cheerio.load(response.data);
    const allAnime = [];
    $('.ranking-list').each((index, element) => {
      const title = $(element).find('.title').text().trim();
      const image = $(element).find('img').attr('data-src') || $(element).find('img').attr('src');
      const link = $(element).find('a').attr('href');
      const rating = parseFloat($(element).find('.score').text().trim()) || 0;
      
      if (title && image && link && rating) {
        allAnime.push({ title, image, link, rating });
      }
    });
    
    const highRatedAnime = allAnime.filter(anime => anime.rating >= 7);
    if (highRatedAnime.length === 0) {
      return await conn.sendMessage(
        m.chat,
        {
          text: "❗ Tidak ada anime dengan rating tinggi yang ditemukan.",
          footer: '👉 [Lihat Anime di MyAnimeList](https://myanimelist.net/topanime.php)'
        },
        { quoted: m }
      );
    }

    const randomAnime = highRatedAnime[Math.floor(Math.random() * highRatedAnime.length)];
    const animePage = await axios.get(randomAnime.link);
    const animePageContent = cheerio.load(animePage.data);

    const characters = [];
    animePageContent('.characters-list .anime_character').each((index, element) => {
      const charName = animePageContent(element).find('.title').text().trim();
      const charImg = animePageContent(element).find('img').attr('data-src') || animePageContent(element).find('img').attr('src');
      const actorName = animePageContent(element).find('.voice-actor .actor').text().trim();
      const actorLink = animePageContent(element).find('.voice-actor a').attr('href');

      if (charName && charImg && actorName && actorLink) {
        characters.push({
          charName,
          charImg,
          actorName,
          actorLink,
        });
      }
    });
    let message = `🎉 *Anime Terbaik: ${randomAnime.title}* 🎉\n\n`;
    message += `🌐 *Link*: ${randomAnime.link}\n`;
    message += `🖼️ *Gambar*: ${randomAnime.image}\n`;
    message += `⭐ *Rating*: ${randomAnime.rating}\n\n`;
    if (characters.length > 0) {
      message += `👤 *Karakter dan Pengisi Suara:*\n`;
      characters.forEach((character) => {
        message += `\n🔹 *Karakter*: ${character.charName}\n`;
        message += `   🖼️ *Gambar*: ${character.charImg}\n`;
        message += `   🎤 *Pengisi Suara*: ${character.actorName}\n`;
        message += `   🌐 *Link Pengisi Suara*: ${character.actorLink}\n`;
      });
    } else {
      message += `❗ Tidak ada informasi karakter dan pengisi suara ditemukan.`;
    }
    await conn.sendMessage(m.chat, { text: message }, { quoted: m });
  } catch (error) {
    console.error('Emror Fetching:', error);
    await conn.sendMessage(
      m.chat,
      { text: "❗ Terjadi kesalahan saat mengambil informasi anime." },
      { quoted: m }
    );
  }
};

handler.command = /^(animetop)$/i;
handler.tags = ['anime'];
handler.help = ['animetop'];

module.exports = handler;