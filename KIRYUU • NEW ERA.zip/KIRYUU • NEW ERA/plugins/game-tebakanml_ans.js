/*
    made by adrianMD
    ch: https://whatsapp.com/channel/0029VaWXWTD8kyyOvgdf1o3x
    
    do not remove the watermark!! 
    
Thank you for using this code ^-^
*/

let similarity = require('similarity')
const threshold = 0.72

let handler = m => m
handler.before = async function(m) {
    let id = 'tebakanml-' + m.chat
    if (!m.quoted || !m.quoted.fromMe || !m.quoted.isBaileys || !m.text || !/Ketik.*teml/i.test(m.quoted.text) || /.*teml/i.test(m.text))
        return !0
    this.tebakanml = this.tebakanml ? this.tebakanml : {}
    if (!(id in this.tebakanml))
        return m.reply('Soal itu telah berakhir')
    if (m.quoted.id == this.tebakanml[id][0].id) {
        let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
        if (isSurrender) {
            clearTimeout(this.tebakanml[id][3])
            delete this.tebakanml[id]
            return m.reply('*Yah Menyerah :(*')
        }
        let json = JSON.parse(JSON.stringify(this.tebakanml[id][1]))
        //m.reply(JSON.stringify(json, null, '\t'))
        if (m.text.toLowerCase() == json.jawaban.toLowerCase().trim()) {
            global.db.data.users[m.sender].exp += this.tebakanml[id][2]
            conn.reply(m.chat, `Jawaban benar ✅\n+${this.tebakanml[id][2]} Exp`, m) 
            clearTimeout(this.tebakanml[id][3])
            delete this.tebakanml[id]
        } else if (similarity(m.text.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold)
            m.reply(`*Dikit Lagi!*`)
        else
            conn.reply(m.chat, 'Salah ❌', m)
    }
    return !0
}
handler.exp = 0

module.exports = handler