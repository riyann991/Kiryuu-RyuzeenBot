let ryan  = async (m, { kiryuu, text }) => {
   
   if (!text) return conn.reply(m.chat, 'masukan namamu!', m)

let psn = `
nama : ${text}
kekuatan : ${pickRandom(global.power)}
`

conn.reply(m.chat, psn, m)
}
ryan.help = ['kekuatan *<name>*']
ryan.tags = ['fun']
ryan.command = /^(kekuatan)$/i
ryan.limit = true

module.exports = ryan

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.power = [
'bisa membuat orang terdekat sange', 
'bisa membuat seseorang menjadi tolol dalam sekejap', 
'bisa membuat kue yang sangat lezat dari tai', 
'bisa membawa orang sekitarnya ke isekai', 
'bisa menjadi ultraman', 
'bisa membuat seseorang jatuh cinta kepadanya dengan 1 kedipan mata', 
'bisa membuat suara seseorang mengecil', 
'bisa melihat isi pikiran seseorang', 
'bisa membuat seseorang yang menggangunya mati', 
'bisa memunculkan dinosaurus', 
'bisa memanggil makhluk halus', 
'bisa menjadi dinosaurus', 
'bisa membuat seseorang putus dengan pasangannya', 
'bisa menciptakan sesuatu yang menarik', 
'bisa membuat boneka sus🗿', 
'bisa menghancurkan dunia dengan bersin', 
'bisa membawa seseorang ke planet lain', 
'bisa mengambil kembali perasaan yang udah pergi', 
'bisa membuat semua org tunduk kepadanya', 
'bisa menjadi pahlawan kebenaran', 
'bisa masuk ke dunia isekai dengan mudah', 
'bisa berubah ubah gender', 
'bisa menciptakan ilmu terlarang', 
'bisa menjadi raja iblis 😈', 
] //tambahin aja mager