let handler = async (m, { text }) => {
    let user = global.db.data.users[m.sender]
    user.afk = + new Date
    user.afkReason = text
    m.reply(`Fitur AFK berhasil *diaktifkan*!\n\n➤ *Username*: @${m.sender.split`@`[0]}\n➤ *Alasan*: ${text ? text : 'Tanpa Alasan'}`)
}
handler.help = ['afk [alasan]']
handler.tags = ['main']
handler.command = /^afk$/i

module.exports = handler