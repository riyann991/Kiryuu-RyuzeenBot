let handler = async (m, { conn, command, text }) => {
	
    if (!text) return conn.reply(m.chat, '• *Example :* .tebakumur udin', m)
    let age = `${pickRandom(global.cekage)}`

let pesan = `╭━━━━°「 *Umurnya ${text}* 」°
┊• Nama : ${text}
┃• Umurnya : ${age}
╰═┅═━––––––๑`
m.reply(pesan) 
}

handler.help = ['tebakumur *<name>*']
handler.tags = ['fun']
handler.command = /^(tebakumur)$/i

module.exports = handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.cekage = [
'1', 
'17', 
'45', 
'89', 
'28', 
'10000🗿tua anjir', 
'34', 
'18 suka nonton bokep nih🗿',
'67', 
'70', 
]

/*TQ TO SANZ - MD JUST FOR FUN 😝*/