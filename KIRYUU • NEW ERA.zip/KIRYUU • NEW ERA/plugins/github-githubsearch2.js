const fetch = require('node-fetch');

let handler = async (m, { conn, text }) => {
  if (!text) {
    return conn.reply(m.chat, 'Masukkan Keyword.', m);
  }
  try {
    let keyword = text.trim();
    let res = await fetch(`https://api.github.com/search/repositories?q=${encodeURIComponent(keyword)}&sort=stars&order=desc&per_page=5`);
    let data = await res.json();
    
    if (!data.items || data.items.length === 0) {
      return conn.reply(m.chat, 'No repositories found for this keyword.', m);
    }
    
    let topRepo = data.items[0];
    let message = `**GitHub Search Results for:** *${keyword}*\n\n`;
    message += `*Top Result: ${topRepo.full_name}*\n`;
    message += `- ⭐ Stars: ${topRepo.stargazers_count}\n`;
    message += `- 📝 Description: ${topRepo.description || 'No description'}\n`;
    message += `- 🔗 URL: ${topRepo.html_url}\n\n`;
    conn.sendFile(m.chat, topRepo.owner.avatar_url, 'avatar.jpg', message, m);

  } catch (error) {
    console.error(error);
    conn.reply(m.chat, 'An error occurred while searching GitHub. Please try again later.', m);
  }
};
handler.command = /^(githubsearch2)$/i;
handler.help = ['githubsearch2 keyword'];
handler.tags = ['github'];
module.exports = handler;