/*
    made by adrianMD x RyanMd 😈
    ch: https://whatsapp.com/channel/0029VaWXWTD8kyyOvgdf1o3x
    
    do not remove the watermark!! 
    
Thank you for using this code ^-^
*/

let fs = require('fs')
let timeout = 120000
let poin = 4999
let handler = async (m, { conn, usedPrefix }) => {
    conn.tebakherohok = conn.tebakherohok ? conn.tebakherohok: {}
    let id = 'tebakherohok-' + m.chat
    if (id in conn.tebakherohok) return conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.tebakherohok[id][0])
    let src = JSON.parse(fs.readFileSync('./lib/tebakherohok.json', 'utf-8'))
    let json = src[Math.floor(Math.random() * src.length)]
    let caption = `
Silahkan Tebak Hero Diatas
*${json.deskripsi}*

╭──────────────╮
▢ Timeout *${(timeout / 1000).toFixed(2)} detik*
▢ Ketik *${usedPrefix}tehok* untuk bantuan
▢ Bonus: *${poin} Exp*
╰──────────────╯

*[ Note ]*
reply pesan ini untuk menjawab
`.trim()
    conn.tebakherohok[id] = [
        await conn.sendFile(m.chat, json.img, 'tebakherohok.jpg', caption, m),
        json, poin,
        setTimeout(() => {
            if (conn.tebakherohok[id]) conn.sendFile(m.chat, json.fullimg, 'herohok.jpg', `Waktu habis!\nJawabannya adalah *${json.jawaban}*`, conn.tebakherohok[id][0])
            delete conn.tebakherohok[id]
        }, timeout)
    ]
}
handler.help = ['tebakherohok']
handler.tags = ['game']
handler.command = /^tebakherohok$/i

handler.group = true
handler.limit = true

module.exports = handler