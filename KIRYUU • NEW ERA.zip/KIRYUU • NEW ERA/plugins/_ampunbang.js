let handler = async (m) => {
    let user = global.db.data.users[m.sender]

    user.warn += 1
    m.reply(`Selamat Peringatan Kamu bertambah 1\n\nPeringatan Kamu: ${user.warn}`)
}
handler.customPrefix = /^(aku kaya)$/i;
handler.command = new RegExp();

handler.limit = true

module.exports = handler