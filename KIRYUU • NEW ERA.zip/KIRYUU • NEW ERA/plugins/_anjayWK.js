const util = require("util");
const path = require("path");

let handler = async (m, { conn }) => {
    let kntl = `./vn/anjay.mp3`
	await conn.sendFile(m.chat, kntl, "anjay.mp3", null, m, true)
};
handler.customPrefix = /^(anjay|anjayy|anjaywk|njay)$/i;
handler.command = new RegExp();

module.exports = handler;