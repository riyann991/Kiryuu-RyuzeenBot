async function before(m) {
    let user = global.db.data.users[m.sender];

    if (user.exp > 10000000000) {
        user.exp = 10000000000;
    } else if (user.exp < 0) {
        user.exp = 0;
    }
 
    if (user.health > 100 ) {
        user.health = 100;
    } else if (user.health < 0) {
        user.health = 0;
    }

    if (user.level > 100000 ) {
        user.level = 100000;
    } else if (user.level < 0) {
        user.level = 0;
    }
    
    if (user.limit > 100000000000000000) {
        user.limit = 100000000000000000;
    } else if (user.limit < 0) {
        user.limit = 0;
    }
    
}

module.exports = { before };