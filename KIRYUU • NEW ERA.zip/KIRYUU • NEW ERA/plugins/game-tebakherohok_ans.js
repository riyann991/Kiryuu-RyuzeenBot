/*
    made by adrianMD x RyanMD😈
    ch: https://whatsapp.com/channel/0029VaWXWTD8kyyOvgdf1o3x
    
    do not remove the watermark!! 
    
Thank you for using this code ^-^
*/

let similarity = require('similarity')
const threshold = 0.72

let handler = m => m
handler.before = async function(m) {
    let id = 'tebakherohok-' + m.chat
    if (!m.quoted || !m.quoted.fromMe || !m.quoted.isBaileys || !m.text || !/Ketik.*tehok/i.test(m.quoted.text) || /.*tehok/i.test(m.text))
        return !0
    this.tebakherohok = this.tebakherohok ? this.tebakherohok : {}
    if (!(id in this.tebakherohok))
        return m.reply('Soal itu telah berakhir')
    if (m.quoted.id == this.tebakherohok[id][0].id) {
        let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
        if (isSurrender) {
            clearTimeout(this.tebakherohok[id][3])
            delete this.tebakherohok[id]
            return m.reply('*Yah Menyerah :(*')
        }
        let json = JSON.parse(JSON.stringify(this.tebakherohok[id][1]))
        //m.reply(JSON.stringify(json, null, '\t'))
        if (m.text.toLowerCase() == json.jawaban.toLowerCase().trim()) {
            global.db.data.users[m.sender].exp += this.tebakherohok[id][2]
            // benar
            conn.reply(m.chat, `Jawaban benar ✅\n+${this.tebakherohok[id][2]} Exp`, m) 
            clearTimeout(this.tebakherohok[id][3])
            delete this.tebakherohok[id]
        } else if (similarity(m.text.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold)
            m.reply(`*Dikit Lagi!*`)
        else
            // salah
            // sticker
            conn.sendImageAsSticker(m.chat, 'https://telegra.ph/file/360d553042f5072e9442d.jpg', m, { packname: global.packname, author: global.author })
            // no sticker
            //conn.reply(m.chat, 'Salah ❌', m)
    }
    return !0
}
handler.exp = 0

module.exports = handler