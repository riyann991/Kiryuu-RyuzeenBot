/*
*<>FLUX, IMAGE AI<>*
SCRAPE BY DAFFA: https://whatsapp.com/channel/0029VaiVeWA8vd1HMUcb6k2S/244
SOURCE: https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
DON'T DELETE THIS WM!
HAPUS WM MANDUL 7 TURUNAN 
HAPUS WM=SDM RENDAH
*KALO LU CONVERT APAPUN FITUR INI,WM JANGAN DIHAPUS!*
"aku janji tidak akan hapus wm ini"
JUM'AT, 06 NOVEMBER 16:42
*/
const axios = require('axios');
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return conn.reply(
      m.chat,
      `kirim perintah dengan format: ${usedPrefix}${command} <prompt>\n\nContoh: ${usedPrefix}${command} pemandangan indah`,
      m
    );
  }
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
  try {
    const result = await fluximg.create(text);
    if (result && result.imageLink) {
      await conn.sendMessage(
        m.chat,
        {
          image: { url: result.imageLink },
          caption: `Hasil Flux:\n\nPrompt: ${text}`,
        },
        { quoted: m }
      );
    } else {
      throw new Error("gagal membuat gambar. Coba lagi.");
    }
  } catch (error) {
    console.error(error);
    conn.reply(
      m.chat,
      "terjadi kesalahan saat membuat gambar.",
      m
    );
  }
};
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
handler.help = ["flux <prompt>"];
handler.tags = ["ai"];
handler.command = ["flux"];
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
module.exports = handler;
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
//scrape by Daffa: https://whatsapp.com/channel/0029VaiVeWA8vd1HMUcb6k2S/244
const fluximg = {
  defaultRatio: "2:3", 

  create: async (query) => {
    const config = {
      headers: {
        accept: "*/*",
        authority: "1yjs1yldj7.execute-api.us-east-1.amazonaws.com",
        "user-agent": "Postify/1.0.0",
      },
    };

    try {
      const response = await axios.get(
        `https://1yjs1yldj7.execute-api.us-east-1.amazonaws.com/default/ai_image?prompt=${encodeURIComponent(
          query
        )}&aspect_ratio=${fluximg.defaultRatio}`,
        config
      );
      return {
        imageLink: response.data.image_link,
      };
    } catch (error) {
      console.error(error);
      throw error;
    }
  },
};
/*
*<>FLUX, IMAGE AI<>*
SCRAPE BY DAFFA: https://whatsapp.com/channel/0029VaiVeWA8vd1HMUcb6k2S/244
SOURCE: https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
DON'T DELETE THIS WM!
HAPUS WM MANDUL 7 TURUNAN 
HAPUS WM=SDM RENDAH 
*KALO LU CONVERT APAPUN FITUR INI,WM JANGAN DIHAPUS!*
"aku janji tidak akan hapus wm ini"
JUM'AT, 06 NOVEMBER 16:42
*/