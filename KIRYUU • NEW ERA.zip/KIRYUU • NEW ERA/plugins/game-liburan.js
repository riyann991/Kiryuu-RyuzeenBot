let handler = async (m, { conn, text }) => {
  const userId = m.sender;
  const user = global.db.data.users[userId];
  const lastVacationDate = user.lastVacationDate || 0;
  const currentTime = new Date().getTime();
  const timeDiff = currentTime - lastVacationDate;

  if (timeDiff < 600000) {
    const remainingTime = 600000 - timeDiff;
    conn.reply(m.chat, `Anda harus menunggu ${remainingTime / 1000} detik lagi sebelum berlibur lagi. ⏳`, m);
    return;
  }

  if (text) {
    const selectedDestinationIndex = parseInt(text) - 1;
    const destinationOptions = getDestinationOptions();

    if (selectedDestinationIndex >= 0 && selectedDestinationIndex < destinationOptions.length) {
      const selectedDestination = destinationOptions[selectedDestinationIndex];
      const vacationInfo = `
🏖️ *Informasi Liburan* 🏖️
📍 Destinasi Liburan: ${selectedDestination}
      `;

      conn.reply(m.chat, `Anda sedang berlibur di ${selectedDestination}!\n\n${vacationInfo}`, m);

      setTimeout(() => {
        const isGoodEnding = Math.random() < 0.5; // 50% kemungkinan untuk ending baik atau buruk
        let ending;

        if (isGoodEnding) {
          ending = "Akhir yang Bahagia! Liburan Anda sangat menyenangkan dan Anda mendapatkan banyak kenangan indah. 🌞";
        } else {
          ending = "Akhir yang Buruk! Liburan Anda tidak berjalan sesuai rencana dan mengalami beberapa kendala. 😢";
        }

        conn.reply(m.chat, `Liburan selesai!\n\n${vacationInfo}\n\n${ending}`, m);
      }, 30000); // Liburan berlangsung selama 30 detik

      user.lastVacationDate = currentTime;
    } else {
      conn.reply(m.chat, 'Pilihan destinasi tidak valid. Liburan dibatalkan.', m);
    }
  } else {
    const destinationList = getDestinationOptions().map((dest, index) => `${index + 1}. ${dest}`).join('\n');
    conn.reply(m.chat, `Silakan pilih destinasi dengan format .liburan [nomor destinasi].\n\nList Destinasi:\n${destinationList}`, m);
  }
};

handler.help = ['liburan'];
handler.tags = ['game'];
handler.command = /^liburan$/i;
handler.register = true;
handler.rpg = false;
handler.group = true;

module.exports = handler;

function getDestinationOptions() {
  return [
    'Bali', 'Pulau Komodo', 'Yogyakarta', 'Jakarta', 'Labuan Bajo',
    'Lombok', 'Bandung', 'Malang', 'Semarang', 'Medan',
    'Surabaya', 'Makassar', 'Banda Aceh', 'Palembang', 'Batam',
    'Pontianak', 'Denpasar', 'Gili Trawangan', 'Kota Tua Jakarta', 'Kawah Putih',
  ];
}