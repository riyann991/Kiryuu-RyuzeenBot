const fetch = require("node-fetch");
const yts = require("yt-search");

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example:* ${usedPrefix + command} *[query]*`;

  await m.reply('Processing...');

  try {
    let search = await yts(text);
    let vid = await search.videos[0];
    let { title, timestamp, views, url } = vid;
    let res = await fetch(`https://apikita.exonity.xyz/api/ytdlp?url=${url}`);
    let load = await res.json();

    if (!load || !load.result || !load.result.audio) {
      throw "Error fetching video data.";
    }
                  /* Weem Dika 😂*/

    let caption = `*[ YOUTUBE PLAY ]*\n*• Caption:* ${title}\n*• Views:* ${views}\n*• Source Yt:* ${url}\n\n\`\`\`Audio will be sent soon\nso please wait a moment\`\`\``;
    await conn.sendMessage(m.chat, { text: caption }, { quoted: m });

    let audioBuffer = await fetch(load.result.audio)
      .then(res => res.arrayBuffer())
      .then(buffer => Buffer.from(buffer));

    await conn.sendMessage(m.chat, {
      audio: audioBuffer,
      mimetype: 'audio/mp4',
      fileName: `${load.result.title}.mp3`,
      caption: load.result.title,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          title: title,
          body: `Views: ${views}`,
          mediaType: 2,
          thumbnailUrl: vid.thumbnail,
          mediaUrl: url
        }
      }
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    throw `Error occurred: ${e.message || "Unable to process your request"}`;
  }
};

handler.help = ["play6"].map((a) => a + ` *[query]*`);
handler.tags = ["downloader"];
handler.command = ["play6"];
handler.register = false;

module.exports = handler;