const util = require("util");
const path = require("path");

let handler = async (m, { conn }) => {
    let kntl = `./vn/wibu.mp3`
	await conn.sendFile(m.chat, kntl, "wibu.mp3", null, m, true)
};
handler.customPrefix = /^(wibu)$/i;
handler.command = new RegExp();

module.exports = handler;