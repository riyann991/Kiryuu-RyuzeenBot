let handler = async (m, { conn, command, text, participants}) => {
    if (!text) return conn.reply(m.chat, 'Ketik Namanya!\n\nExample : .keluarga penjabat', m)
	let who
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid]
        who = member[Math.floor(Math.random() * member.length)]
    } else {
        let member = participants.map(u => u.id)
        who = member[Math.floor(Math.random() * member.length)]
    }
    let who2
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid]
        who2 = member[Math.floor(Math.random() * member.length)]
    } else {
        let member = participants.map(u => u.id)
        who2 = member[Math.floor(Math.random() * member.length)]
    }
	let who3
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid]
        who3 = member[Math.floor(Math.random() * member.length)]
    } else {
        let member = participants.map(u => u.id)
        who3 = member[Math.floor(Math.random() * member.length)]
    }
    let who4
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid]
        who4 = member[Math.floor(Math.random() * member.length)]
    } else {
        let member = participants.map(u => u.id)
        who4 = member[Math.floor(Math.random() * member.length)]
    }   
	let who5
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid]
        who5 = member[Math.floor(Math.random() * member.length)]
    } else {
        let member = participants.map(u => u.id)
        who5 = member[Math.floor(Math.random() * member.length)]
    }
    let who6
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid]
        who6 = member[Math.floor(Math.random() * member.length)]
    } else {
        let member = participants.map(u => u.id)
        who6 = member[Math.floor(Math.random() * member.length)]
    }
	let who7
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid]
        who7 = member[Math.floor(Math.random() * member.length)]
    } else {
        let member = participants.map(u => u.id)
        who7 = member[Math.floor(Math.random() * member.length)]
    }
    let who8
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid]
        who8 = member[Math.floor(Math.random() * member.length)]
    } else {
        let member = participants.map(u => u.id)
        who8 = member[Math.floor(Math.random() * member.length)]
    }
	let who9
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid]
        who9 = member[Math.floor(Math.random() * member.length)]
    } else {
        let member = participants.map(u => u.id)
        who9 = member[Math.floor(Math.random() * member.length)]
    }
    let who10
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid]
        who10 = member[Math.floor(Math.random() * member.length)]
    } else {
        let member = participants.map(u => u.id)
        who10 = member[Math.floor(Math.random() * member.length)]
    }
	let who11
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid]
        who11 = member[Math.floor(Math.random() * member.length)]
    } else {
        let member = participants.map(u => u.id)
        who11 = member[Math.floor(Math.random() * member.length)]
    }    
           	
  conn.reply(m.chat, `
〔 Keluarga ${text} 〕

*Ayahnya* : @${who.split`@`[0]}
*Ibunya* : @${who2.split`@`[0]}
*Kakeknya* : @${who3.split`@`[0]}
*Neneknya* : @${who4.split`@`[0]}
*Pamannya* : @${who5.split`@`[0]}
*Bibinya* : @${who6.split`@`[0]}
*Anak Pertama* : @${who7.split`@`[0]}
*Anak Kedua* : @${who8.split`@`[0]}
*Anak Ketiga* : @${who9.split`@`[0]}
*Anak ke empat* : @${who10.split`@`[0]}
*Anak ke lima* : @${who11.split`@`[0]}
`.trim(), m)
}
handler.help = ['keluarga <nama>']
handler.tags = ['fun']
handler.command = /^keluarga/i
handler.group = true

module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}