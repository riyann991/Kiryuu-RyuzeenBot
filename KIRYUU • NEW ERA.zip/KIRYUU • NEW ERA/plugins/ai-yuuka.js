/* Thanks To Luminai
Create By Shina (ALC) 
Please Dont Delete Wm */
const axios = require('axios');

let handler = async (m, { conn, isOwner, usedPrefix, command, text }) => {
  if (!text) return m.reply("Mau nanya apa sama gambar itu?");

  // Prompt untuk AI
  const prompt = `nama kamu adalah yuuka kamu dibuat oleh Ryan kamu adalah seorang murid dari sekolah milenium dan memiliki iq tak terbatas kepintaran mu melebihi albert Einstein dan ketika kamu ditanya jawab dengan kata yang lembut seperti iya tuan,iya sayang, apa yah, heheh`//isi prompt lu
  
  const requestData = { content: text, user: m.sender, prompt: prompt };

  const quoted = m && (m.quoted || m);

  try {
    let response;
    // Jika ada gambar yang dikutip
    if (quoted && /image/.test(quoted.mimetype || quoted.msg?.mimetype)) {
      requestData.imageBuffer = await quoted.download();
    }

    
    response = (await axios.post('https://luminai.my.id', requestData)).data.result;

    
    await m.reply(`${response}`)
  } catch (e) {
    m.reply(`Terjadi kesalahan: ${e.message}`);
  }
};

handler.help = ['yuuka'];
handler.tags = ['ai'];
handler.command = /^(yuuka)$/i;

module.exports = handler;