const axios = require('axios');
let handler = async (m, { usedPrefix, command, conn, text }) => {
conn.sendMessage(m.chat, { image: { url: 'https://fantox-cosplay-api.onrender.com/' }, caption: 'Done Desuu~' }, { quoted: m })
}
handler.help = ['cosplay2']
handler.tags = ['asupan']
handler.command = /^cosplay2$/i
handler.premium = true
module.exports = handler;