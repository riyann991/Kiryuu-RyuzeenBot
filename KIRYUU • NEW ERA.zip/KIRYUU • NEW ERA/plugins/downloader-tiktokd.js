const axios = require('axios');

const handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply('❗ *Masukkan Link Tiktok!*');
  }

  try {
    const apiUrl = `https://tikwm.com/api/?url=${encodeURIComponent(text)}`;
    const response = await axios.get(apiUrl);
    const { data } = response;
    if (data.code === 0 && data.data) {
      const videoData = data.data;
      const videoUrl = videoData.play; 
      const musicUrl = videoData.music_info.play;
      const musicTitle = videoData.music_info.title;
      const videoTitle = videoData.title;
      const authorName = videoData.author.nickname;
      const coverImage = videoData.cover;
      
      const fkon = {
        key: {
          fromMe: false,
          participant: `${m.sender.split('@')[0]}@s.whatsapp.net`,
          ...(m.chat ? { remoteJid: '222222222222@s.whatsapp.net' } : {}),
        },
        message: {
          contactMessage: {
            displayName: `${authorName}`,
            vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:${authorName}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
          },
        },
      };
      
      await conn.sendMessage(m.chat, {
        video: { url: videoUrl },
        caption: `✨ *TikTok Video Downloader* ✨\n\n🎥 *Video Title:* ${videoTitle}\n👤 *Author:* ${authorName}\n🎶 *Music Title:* ${musicTitle}\n🔗 *Original Video:* ${text}`,
        mimetype: 'video/mp4',
        thumbnail: { url: coverImage }
      }, { quoted: fkon });

      if (musicUrl) {
        await conn.sendMessage(m.chat, {
          audio: { url: musicUrl },
          caption: `🎶 *music dari video:* ${musicTitle}`,
          mimetype: 'audio/mpeg',
        }, { quoted: fkon });
      }

    } else {
      m.reply('⚠️ *gagal.*');
    }
  } catch (error) {
    console.error('Error downloading TikTok video:', error.message);
    m.reply('❗*Ada yang Error Pada Url, Pastikan Url valid*');
  }
};

handler.help = ['tiktokd'];
handler.tags = ['downloader'];
handler.command = /^(tiktokd)$/i;

module.exports = handler;