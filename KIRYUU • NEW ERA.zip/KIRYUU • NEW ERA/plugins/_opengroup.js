let handler = async (m, { conn, args, text, usedPrefix: _p, command, isROwner }) => {

let pesan = `
*group berhasil di buka tuan..*

━━━━━☐━━━━━
*Selamat Pagi 🌞*

"jangan lupa sarapan dan semangat untuk menjalani hari ini"
`
conn.groupSettingUpdate(m.chat, 'not_announcement')
conn.reply(m.chat, pesan, m)
}
handler.customPrefix = /^(🥱)$/i 
handler.command = new RegExp
handler.botAdmin = true
handler.owner = true
handler.group = true
module.exports = handler