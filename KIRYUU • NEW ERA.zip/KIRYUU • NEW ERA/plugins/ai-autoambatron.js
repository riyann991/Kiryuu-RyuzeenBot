const fetch = require('node-fetch');

// Fungsi untuk menghasilkan ID unik
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

/*
   * Menggunakan Ambatron AI
   * Disarankan menggunakan https://lumin-ai.xyz
   * Contribution: Vynaa Valerie 
*/

function ambatronAi(content) {
  return new Promise(async (resolve, reject) => {
    const url = 'https://www.blackbox.ai/api/chat';

    const headers = {
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, Gecko) Chrome/128.0.0.0 Mobile Safari/537.36',
      'Referer': 'https://www.blackbox.ai/agent/ambatron'
    };

    const body = {
      messages: [
        {
          id: generateId(),
          content,
          role: "user"
        }
      ],
      id: generateId(),
      previewToken: null,
      userId: null,
      codeModelMode: true,
      agentMode: {
        mode: true,
        id: "ambatron",
        name: "Ambatron"
      },
      trendingAgentMode: {},
      isMicMode: false,
      maxTokens: 1024,
      isChromeExt: false,
      githubToken: null,
      clickedAnswer2: false,
      clickedAnswer3: false,
      clickedForceWebSearch: false,
      visitFromDelta: false,
      mobileClient: false
    };

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(body),
        compress: true
      });

      let data = await response.text(); 
      data = data.replace(/^\$@\$.+?\$@\$/, ''); // Menghapus karakter khusus dari respons

      resolve(data);
    } catch (error) {
      reject('Error:', error);
    }
  });
}

let handler = async (m, { conn, text }) => {
    conn.ambatron = conn.ambatron ? conn.ambatron : {};
   
    if (!text) throw `*• Example:* .autoambatron *[on/off]*`;

    if (text === "on") {
        conn.ambatron[m.sender] = {
            pesan: []
        };
        // kalian bisa ganti ini untuk tanda apakah sesi sudah aktif atau belum
        m.reply("[ √ ] Berhasil mengaktifkan fitur percakapan dengan ambatron ai");
    } else if (text === "off") {
        delete conn.ambatron[m.sender];
        // ini kalau sudah selesai sesi nya di tutup
        m.reply("[ √ ] Berhasil menonaktifkan fitur percakapan dengan ambatron ai");
    }
};

handler.before = async (m, { conn }) => {
    conn.ambatron = conn.ambatron ? conn.ambatron : {};
    if (m.isBaileys && m.fromMe) return;
    if (!m.text) return;
    if (!conn.ambatron[m.sender]) return;

    // prefix untuk mulai dan selesai sesi
    if (
        m.text.startsWith(".") ||
        m.text.startsWith("#") ||
        m.text.startsWith("!") ||
        m.text.startsWith("/") ||
        m.text.startsWith("\\/")
    ) return;

    if (conn.ambatron[m.sender] && m.text) {
        let name = conn.getName(m.sender);
        const message = [
            ...conn.ambatron[m.sender].pesan,
            `p`,
            m.text
        ];
  try {
    // Panggil Ambatron AI untuk mendapatkan respons dari teks yang diberikan
    const response = await ambatronAi(m.text);

    // Kirimkan hasil dari AI sebagai pesan
    await conn.reply(m.chat, response, m);
  } catch (error) {
    console.error(error);
    await conn.reply(m.chat, 'Maaf, terjadi kesalahan dalam memproses permintaan AI.', m);
  }
}
};
handler.help = handler.command = ['autoambatron'];
handler.tags = ["ai"];
handler.limit = true;
handler.owner = false;
handler.group = false;

module.exports = handler;