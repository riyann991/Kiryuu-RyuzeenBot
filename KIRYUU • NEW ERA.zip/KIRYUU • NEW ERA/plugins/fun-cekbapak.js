let handler = async (m, { conn, command, text }) => {
	
    if (!text) return conn.reply(m.chat, '• *Example :* .cekbapak udin', m)
    let bpk = `${pickRandom(global.namabpk)}`

let pesan = `╭━━━━°「 *BAPAK ${text}* 」°
┊• Nama : ${text}
┃• Bapaknya : ${bpk}
╰═┅═━––––––๑`
m.reply(pesan) 
}

handler.help = ['cekbapak *<name>*']
handler.tags = ['fun']
handler.command = /^(cekbapak)$/i

module.exports = handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.namabpk = [
'jamal', 
'markona', 
'budi', 
'dimas', 
'sawaludin', 
'jalaludin', 
'markona', 
'rafi ahmad', 
'roy kiyoshi', 
'bambang', 
'darwani', 
'darwin', 
'kopet', 
'jono', 
'joni', 
'atta', 
'thorik', 
'ragil', 
'vinsen', 
'udin', 
'winda basudara', 
'mr ambatukam', 
'gerald Vincen', 
'rizzpiw', 
'rioo', 
'permenmd', 
'dhan', 
'luh dikick dari kk'
]

/*TQ TO SANZ - MD JUST FOR FUN 😝*/