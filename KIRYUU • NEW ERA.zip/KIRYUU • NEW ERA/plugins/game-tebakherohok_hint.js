/*
    made by adrianMD x RyanMD😈
    ch: https://whatsapp.com/channel/0029VaWXWTD8kyyOvgdf1o3x
    
    do not remove the watermark!! 
    
Thank you for using this code ^-^
*/

let handler = async (m, { conn }) => {
    conn.tebakherohok = conn.tebakherohok ? conn.tebakherohok : {}
    let id = 'tebakherohok-' + m.chat
    if (!(id in conn.tebakherohok)) throw false
    let json = conn.tebakherohok[id][1]
    m.reply('Clue : ' + '```' + json.jawaban.replace(/[AIUEOaiueo]/ig, '_') + '```' + '\n\n_*Jangan Balas Chat Ini Tapi Balas Soalnya*_')
}
handler.command = /^tehok$/i
handler.limit = true
module.exports = handler