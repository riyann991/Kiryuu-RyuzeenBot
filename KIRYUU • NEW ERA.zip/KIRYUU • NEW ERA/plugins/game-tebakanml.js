/*
    made by adrianMD
    ch: https://whatsapp.com/channel/0029VaWXWTD8kyyOvgdf1o3x
    
    do not remove the watermark!! 
    
Thank you for using this code ^-^
*/

let fs = require('fs')
let timeout = 120000
let poin = 4999
let handler = async (m, { conn, usedPrefix }) => {
    conn.tebakanml = conn.tebakanml ? conn.tebakanml: {}
    let id = 'tebakanml-' + m.chat
    if (id in conn.tebakanml) return conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.tebakanml[id][0])
    let src = JSON.parse(fs.readFileSync('./lib/tebakanml.json', 'utf-8'))
    let json = src[Math.floor(Math.random() * src.length)]
    let caption = `
*${json.soal}*

╭────────────────╮
▢ Timeout *${(timeout / 1000).toFixed(2)} detik*
▢ Ketik *${usedPrefix}teml* untuk bantuan
▢ Bonus: *${poin} Exp*
╰────────────────╯

*[ Note ]*
reply pesan ini untuk menjawab
`.trim()
    conn.tebakanml[id] = [
        await m.reply(caption), 
        json, poin,
        setTimeout(() => {
            if (conn.tebakanml[id]) conn.reply(m.chat, `Waktu habis!\nJawabannya adalah *${json.jawaban}*`, conn.tebakanml[id][0])
            delete conn.tebakanml[id]
        }, timeout)
    ]
}
handler.help = ['tebakanml']
handler.tags = ['game']
handler.command = /^tebakanml$/i

handler.group = true
handler.limit = true

module.exports = handler