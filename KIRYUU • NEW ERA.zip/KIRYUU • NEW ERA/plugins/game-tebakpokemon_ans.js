/*
    made by adrianMD
    ch: https://whatsapp.com/channel/0029VaWXWTD8kyyOvgdf1o3x
    
    do not remove the watermark!! 
    
Thank you for using this code ^-^
*/

let similarity = require('similarity')
const threshold = 0.72

let handler = m => m
handler.before = async function(m) {
    let id = 'tebakpokemon-' + m.chat
    if (!m.quoted || !m.quoted.fromMe || !m.quoted.isBaileys || !m.text || !/Ketik.*tepo/i.test(m.quoted.text) || /.*tepo/i.test(m.text))
        return !0
    this.tebakpokemon = this.tebakpokemon ? this.tebakpokemon : {}
    if (!(id in this.tebakpokemon))
        return m.reply('Soal itu telah berakhir')
    if (m.quoted.id == this.tebakpokemon[id][0].id) {
        let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
        if (isSurrender) {
            clearTimeout(this.tebakpokemon[id][3])
            delete this.tebakpokemon[id]
            return m.reply('*Yah Menyerah :(*')
        }
        let json = JSON.parse(JSON.stringify(this.tebakpokemon[id][1]))
        //m.reply(JSON.stringify(json, null, '\t'))
        if (m.text.toLowerCase() == json.jawaban.toLowerCase().trim()) {
            global.db.data.users[m.sender].exp += this.tebakpokemon[id][2]
            conn.reply(m.chat, `Jawaban benar ✅\n+${this.tebakpokemon[id][2]} Exp`, m) 
            clearTimeout(this.tebakpokemon[id][3])
            delete this.tebakpokemon[id]
        } else if (similarity(m.text.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold)
            m.reply(`*Dikit Lagi!*`)
        else
            conn.reply(m.chat, 'Salah ❌', m)
    }
    return !0
}
handler.exp = 0

module.exports = handler