const util = require("util");
const path = require("path");

let handler = async (m, { conn }) => {
    let kntl = `./src/vn/rawr.opus`
	await conn.sendFile(m.chat, kntl, "rawr.opus", null, m, true)
};
handler.customPrefix = /^(ror|rawr|rarr|rorr)$/i;
handler.command = new RegExp();

module.exports = handler;