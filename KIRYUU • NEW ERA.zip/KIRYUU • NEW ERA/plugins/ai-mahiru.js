const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `*Example:* ${usedPrefix + command} hai`;
    conn.mahiruai = conn.mahiruai ? conn.mahiruai : {};
    if (!conn.mahiruai[m.sender]) {
        conn.mahiruai[m.sender] = {
            pesan: []
        };
        conn.mahiruai[m.sender].timeout = setTimeout(() => {
            delete conn.mahiruai[m.sender];
        }, 300000);

        //m.reply(`Halo \`${m.name}\`👋, Saya siap membantu anda`);
    } else {
        clearTimeout(conn.mahiruai[m.sender].timeout);
        conn.mahiruai[m.sender].timeout = setTimeout(() => {
            delete conn.mahiruai[m.sender];
        }, 300000);
    }

    let name = conn.getName(m.sender);
    const previousMessages = conn.mahiruai[m.sender].pesan;
  
/** - Ubah prompt ini sesuaikan dengan keinginan mu 
    - Usahakan berikan logic yang masuk akal dan mudah di pahami!
**/
    const messages = [
        { role: "system", content: "kamu adalah *Mahiruu Shina*, Seorang Asisten pribadi yang di buat oleh *ryann* yang siap membantu kamu kapan pun!" },
        { role: "assistant", content: `Kamu adalah *Mahiruu Shina*, jika disuruh memperkenalkan diri maka jawablah nama ku mahiru aku dibuat oleh ryann apa ada yang bisa aku bantu ehe? eh kalo gak ada maaf , kamu adalah ai yang polos baik hati dan penyayang gunakan kata aku untuk manggil nama kamu sendiri, dan gunakan kata kamu atau tuan ke ${name}, gunakan kata lembut seperti hai, alo, eh, kenapa, gomen, ehe` },
        ...previousMessages.map((msg, i) => ({ role: i % 2 === 0 ? 'user' : 'assistant', content: msg })),
        { role: "user", content: text }
    ];
    try {
        const chat = async function(message) {
            return new Promise(async (resolve, reject) => {
                try {
                    const params = {
                        message: message,
                        apikey: btc
                    };
                    const { data } = await axios.post('https://api.botcahx.eu.org/api/search/openai-custom', params);
                    resolve(data);
                } catch (error) {
                    reject(error);
                }
            });
        };

        let res = await chat(messages);
        await  conn.sendMessage(m.chat, {
    // ini nama dari karakter utama
    text: "⬣───「 *Mahiruu Shina* 」───⬣" + "\n\n" + res.result,
    contextInfo: {
      externalAdReply: {  
        // title di bagian gambar
        title: "MAHIRU-AI",
        body: '',
        // gambar karakter kalian
        thumbnailUrl:`https://pomf2.lain.la/f/21mank6.jpg`,
        // `${pickRandom(global.img)}`
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m });
        if (res && res.result) {
            //await m.reply(res.result);
            conn.mahiruai[m.sender].pesan = messages.map(msg => msg.content);
        } else {
            throw "Kesalahan dalam mengambil data";
        }
    } catch (e) {
        throw eror
    }
};

handler.help = handler.command = ['mahiru']
handler.tags = ["ai"];
handler.limit = true;
handler.owner = false;
handler.group = false;

module.exports = handler;