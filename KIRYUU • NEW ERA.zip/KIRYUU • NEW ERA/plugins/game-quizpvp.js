/**
 * DannTeam
 * Instagram: @dannstfu, @educoding_id
 * Quiz PvP
*/

let danz = async (m, {
  conn,
  text,
  usedPrefix,
  command
}) => {
  conn.quizpvp = conn.quizpvp ? conn.quizpvp: {}
  if (!text) return m.reply(`Tag teman yang ingin kamu ajak bermain!\n\nContoh: ${usedPrefix + command} @temanmu`)

  let opponent = m.mentionedJid[0]
  if (!opponent) return m.reply('Tag teman yang ingin kamu ajak bermain.')

  if (conn.quizpvp[m.chat]) return m.reply('Game sedang berlangsung di chat ini!')

  conn.quizpvp[m.chat] = {
    player1: m.sender,
    player2: opponent,
    question: null,
    status: 'pending',
  }

  m.reply(`Menunggu konfirmasi dari @${opponent.split('@')[0]} untuk bergabung ke Quiz PvP. Balas "terima" untuk bergabung atau "tolak" untuk menolak.`, null, {
    mentions: [opponent]
  })

  setTimeout(() => {
    if (conn.quizpvp[m.chat] && conn.quizpvp[m.chat].status === 'pending') {
      m.reply(`@${opponent.split('@')[0]} tidak merespon dalam 60 detik. Quiz dibatalkan.`, null, {
        mentions: [opponent]
      })
      delete conn.quizpvp[m.chat]
    }
  },
    60000)
}

danz.before = async function (m, {
  conn
}) {
  conn.quizpvp = conn.quizpvp ? conn.quizpvp: {}

  if (conn.quizpvp[m.chat]) {
    let room = conn.quizpvp[m.chat]

    if (room.status === 'pending' && m.sender === room.player2) {
      if (/terima/i.test(m.text)) {
        room.status = 'playing'
        room.question = question()

        await conn.reply(m.chat, `— Quiz PvP —\n\nSoal: ${room.question.question}\nWaktu: 120 detik`, m)

        setTimeout(() => {
          if (conn.quizpvp[m.chat] && conn.quizpvp[m.chat].status === 'playing') {
            m.reply('Waktu habis! Tidak ada pemenang dalam Quiz PvP kali ini.')
            delete conn.quizpvp[m.chat]
          }
        },
          120000)
      } else if (/tolak/i.test(m.text)) {
        await conn.sendMessage(room.player1, `Permintaan Quiz PvP telah ditolak oleh @${m.sender.split('@')[0]}.`, null, {
          mentions: [m.sender]
        })
        await conn.sendMessage(m.chat, `Permintaan Quiz PvP telah ditolak oleh @${m.sender.split('@')[0]}.`, null, {
          mentions: [m.sender]
        })
        delete conn.quizpvp[m.chat]
      }
    }

    if (room.status === 'playing') {
      if (m.text.toLowerCase() === room.question.answer.toLowerCase()) {
        let winner = m.sender
        let loser = winner === room.player1 ? room.player2: room.player1

        db.data.users[winner].limit += 5
        db.data.users[winner].money += 1000

        await conn.reply(winner, 'Selamat! Kamu memenangkan Quiz PvP.\n\nMendapatkan Hadiah:\nLimit: 5\nMoney: 1000', m)
        await conn.reply(m.chat, `@${winner.split("@")[0]} menang dalam pertandingan Quiz PvP!`, null, {
          mentions: [winner]
        })
        await conn.reply(loser, 'Kamu kalah dalam Quiz PvP.', m)
        await conn.reply(m.chat, `@${loser.split("@")[0]} kalah dalam pertandingan Quiz PvP!`, null, {
          mentions: [loser]
        })

        delete conn.quizpvp[m.chat]
      }
    }
  }
}

danz.command = danz.help = ['quizpvp']
danz.tags = ['game']
danz.limit = true
danz.group = true

module.exports = danz

function question() {
  const questions = [{
    question: 'Ibukota Indonesia?',
    answer: 'Jakarta'
  },
    {
      question: 'Planet terdekat dengan matahari?',
      answer: 'Merkurius'
    },
    {
      question: 'Hasil dari 3 + 4?',
      answer: '7'
    },
  ]

  return questions[Math.floor(Math.random() * questions.length)]
}