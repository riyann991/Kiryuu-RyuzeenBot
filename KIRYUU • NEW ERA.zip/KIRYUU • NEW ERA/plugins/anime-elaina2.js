let handler = async (m, { conn }) => {
	conn.sendFile(m.chat, `https://api.lolhuman.xyz/api/random/elaina?apikey=${global.lol}`, 'elaina.jpg', '*DONE*', m)
}
handler.help = ['elaina2']
handler.tags = ['anime']

handler.command = /^(elaina2)$/i
handler.premium = false
handler.register = true
handler.limit = 1
module.exports = handler