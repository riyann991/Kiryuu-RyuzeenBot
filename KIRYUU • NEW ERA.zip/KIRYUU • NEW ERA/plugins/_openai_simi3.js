var axios = require('axios');

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `*Example:* ${usedPrefix + command} hello`

    const data = new URLSearchParams();
    data.append('text', text);
    data.append('lc', 'id');
    data.append('=', '');

    const config = {
      method: 'post',
      url: 'https://simsimi.vn/web/simtalk',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'X-Requested-With': 'XMLHttpRequest'
      },
      data: data
    };

    let { data: result } = await axios(config)
    await m.reply(result.success)
}
handler.command = ['simi3']
handler.tags = ['ai']
handler.help = ['simi3'].map(_ => _ + " " + "<query>")
handler.limit = true

module.exports = handler