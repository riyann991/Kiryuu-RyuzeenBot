let handler = async (m, { conn, command, text }) => {
conn.reply(m.chat, `aku manusia astral dri planet 0999🤓jomolanet😘
`.trim(), m)
}
handler.customPrefix = /^(kamu siapa)$/i 
handler.command = new RegExp

module.exports = handler;