let handler = async (m, { conn, command, text }) => {
conn.reply(m.chat, `malam sayang😘
`.trim(), m)
}
handler.customPrefix = /^(malam)$/i 
handler.command = new RegExp

module.exports = handler;