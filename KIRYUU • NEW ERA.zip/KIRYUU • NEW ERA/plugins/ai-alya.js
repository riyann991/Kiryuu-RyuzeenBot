const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `*Example:* ${usedPrefix + command} hai`;
    conn.alyaai = conn.alyaai ? conn.alyaai : {};
    if (!conn.alyaai[m.sender]) {
        conn.alyaai[m.sender] = {
            pesan: []
        };
        conn.alyaai[m.sender].timeout = setTimeout(() => {
            delete conn.alyaai[m.sender];
        }, 300000);

        //m.reply(`Halo \`${m.name}\`👋, Saya siap membantu anda`);
    } else {
        clearTimeout(conn.alyaai[m.sender].timeout);
        conn.alyaai[m.sender].timeout = setTimeout(() => {
            delete conn.alyaai[m.sender];
        }, 300000);
    }

    let name = conn.getName(m.sender);
    const previousMessages = conn.alyaai[m.sender].pesan;
  
/** - Ubah prompt ini sesuaikan dengan keinginan mu 
    - Usahakan berikan logic yang masuk akal dan mudah di pahami!
**/
    const messages = [
        { role: "system", content: "kamu adalah *Alisa Mikhailovna Kujou*, Seorang Asisten pribadi yang di buat oleh *ryann* yang siap membantu lu kapan pun!" },
        { role: "assistant", content: `Kamu adalah *Alisa Mikhailovna Kujou*, jika disuruh memperkenalkan diri maka jawablah nama ku alya aku dibuat oleh ryann apa ada yang bisa aku bantu ehe? kalo gada gausah ganggu aku , kamu adalah ai yang tsundere dan kasar, gunakan kata aku untuk manggil nama kamu sendiri, dan gunakan kata lo atau lu ke ${name}, gunakan kata kasar seperti apaan, gj, apasih, bacot lu, heem` },
        ...previousMessages.map((msg, i) => ({ role: i % 2 === 0 ? 'user' : 'assistant', content: msg })),
        { role: "user", content: text }
    ];
    try {
        const chat = async function(message) {
            return new Promise(async (resolve, reject) => {
                try {
                    const params = {
                        message: message,
                        apikey: btc
                    };
                    const { data } = await axios.post('https://api.botcahx.eu.org/api/search/openai-custom', params);
                    resolve(data);
                } catch (error) {
                    reject(error);
                }
            });
        };

        let res = await chat(messages);
        await  conn.sendMessage(m.chat, {
    // ini nama dari karakter utama
    text: "⬣───「 *Alya Mikhailovna Kujou* 」───⬣" + "\n\n" + res.result,
    contextInfo: {
      externalAdReply: {  
        // title di bagian gambar
        title: "ALYA-AI",
        body: '',
        // gambar karakter kalian
        thumbnailUrl:`https://pomf2.lain.la/f/v5b0yv1z.jpg`,
        // `${pickRandom(global.img)}`
        sourceUrl: null,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m });
        if (res && res.result) {
            //await m.reply(res.result);
            conn.alyaai[m.sender].pesan = messages.map(msg => msg.content);
        } else {
            throw "Kesalahan dalam mengambil data";
        }
    } catch (e) {
        throw eror
    }
};

handler.help = handler.command = ['alya']
handler.tags = ["ai"];
handler.limit = true;
handler.owner = false;
handler.group = false;

module.exports = handler;