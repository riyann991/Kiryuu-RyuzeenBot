let handler = async (m, { conn, command, text }) => {
	
    if (!text) return conn.reply(m.chat, 'Masuk pertanyaan!', m)
	
  conn.reply(m.chat, `
Pertanyaan : ${text}

Jawaban : *${Math.floor(Math.random() * 101)}* %
`.trim(), m)
}
handler.help = ['rate <text>']
handler.tags = ['fun']
handler.command = /^rate/i
handler.limit = true

module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}