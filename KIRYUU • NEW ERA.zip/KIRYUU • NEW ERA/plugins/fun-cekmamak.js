let handler = async (m, { conn, command, text }) => {
	
    if (!text) return conn.reply(m.chat, '• *Example :* .cekmamak nurlina', m)
    let mmk = `${pickRandom(global.namammk)}`

let pesan = `╭━━━━°「 *MAMAK ${text}* 」°
┊• Nama : ${text}
┃• Mamaknya : ${mmk}
╰═┅═━––––––๑`
m.reply(pesan) 
}

handler.help = ['cekmamak *<name>*']
handler.tags = ['fun']
handler.command = /^(cekmamak)$/i

module.exports = handler

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.namammk = [
'nurlina', 
'markona', 
'nana', 
'rose', 
'rini', 
'fitriana', 
'ibu jeje', 
'nagita slavina', 
'elaina chan', 
'ibu mira', 
'ibu wanti', 
'risma', 
'orgil', 
'memek', 
'ibu marni', 
'jenny', 
'freya jkt48', 
'ragil', 
'cristhy jkt48', 
'marni sumarni', 
'windi barusadar', 
'mr ambajenny', 
'makk lo bencong', 
'makk jubaidah', 
'makk loo bapak lo sendiri', 
'mamak lo udh *****', 
'diniii', 
'luh dikick dari kk'
]

/*TQ TO SANZ - MD JUST FOR FUN 😝*/