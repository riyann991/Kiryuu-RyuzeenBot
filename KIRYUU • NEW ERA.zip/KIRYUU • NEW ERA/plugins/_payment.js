let handler = async (m, { conn }) => {
let ye = `@${m.sender.split`@`[0]}`
let esce = `
PAYMENT 💰
====================
Dana:
•6287873446580
Pulsa All:
•6287873446580
Gopay:
•6287873446580
Ovo:
•6287873446580
Qris:
• belum ada 

type *.owner* untuk pembayaran lebih lanjut ^ _ ^
===================
`
await conn.sendMessage(m.chat, {
  text: esce,
  contextInfo: {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: '120363303246249933@newsletter',
      serverMessageId: -1,
      newsletterName: "Kiryuu Ryuuzeen • By Ryan"
    }
  }
}, {
  quoted: m
})
}
handler.command = /^(payment|pay)$/i
handler.group = true

module.exports = handler