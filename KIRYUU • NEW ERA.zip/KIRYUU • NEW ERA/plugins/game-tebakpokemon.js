/*
    made by adrianMD
    ch: https://whatsapp.com/channel/0029VaWXWTD8kyyOvgdf1o3x
    
    do not remove the watermark!! 
    
Thank you for using this code ^-^
*/

let fs = require('fs')
let timeout = 120000
let poin = 4999
let handler = async (m, { conn, usedPrefix }) => {
    conn.tebakpokemon = conn.tebakpokemon ? conn.tebakpokemon: {}
    let id = 'tebakpokemon-' + m.chat
    if (id in conn.tebakpokemon) return conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.tebakpokemon[id][0])
    let src = JSON.parse(fs.readFileSync('./lib/tebakpokemon.json', 'utf-8'))
    let json = src[Math.floor(Math.random() * src.length)]
    let caption = `
Apa nama pokemon diatas? 

*${json.deskripsi}*

╭────────────────╮
▢ Timeout *${(timeout / 1000).toFixed(2)} detik*
▢ Ketik *${usedPrefix}tepo* untuk bantuan
▢ Bonus: *${poin} Exp*
╰────────────────╯

*[ Note ]*
reply pesan ini untuk menjawab
`.trim()
    conn.tebakpokemon[id] = [
        await conn.sendFile(m.chat, json.img, 'pokemon.jpg', caption, m),
        json, poin,
        setTimeout(() => {
            if (conn.tebakpokemon[id]) conn.reply(m.chat, `Waktu habis!\nJawabannya adalah *${json.jawaban}*`, conn.tebakpokemon[id][0])
            delete conn.tebakpokemon[id]
        }, timeout)
    ]
}
handler.help = ['tebakpokemon']
handler.tags = ['game']
handler.command = /^tebakpokemon$/i

handler.group = true
handler.limit = true

module.exports = handler