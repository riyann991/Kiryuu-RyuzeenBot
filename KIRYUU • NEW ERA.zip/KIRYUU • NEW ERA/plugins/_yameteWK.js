const util = require("util");
const path = require("path");

let handler = async (m, { conn }) => {
    let kntl = `./vn/yamte.mp3`
	await conn.sendFile(m.chat, kntl, "yamte.mp3", null, m, true)
};
handler.customPrefix = /^(yameteh|yamete|ahh)$/i;
handler.command = new RegExp();

module.exports = handler;