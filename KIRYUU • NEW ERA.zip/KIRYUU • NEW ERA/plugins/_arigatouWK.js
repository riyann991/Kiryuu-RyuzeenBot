const util = require("util");
const path = require("path");

let handler = async (m, { conn }) => {
    let kntl = `./src/vn/arigatou.opus`
	await conn.sendFile(m.chat, kntl, "arigatou.opus", null, m, true)
};
handler.customPrefix = /^(arigatou|arigato|makasih|mksih)$/i;
handler.command = new RegExp();

module.exports = handler;