let fetch = require('node-fetch')
let axios = require('axios')
let { sticker5 } = require('../lib/sticker.js') // Pastikan fungsi sticker5 ada dalam file ini
let MessageType = require('@adiwajshing/baileys')

let handler = async (m, { conn, args, usedPrefix, command }) => {
    let who
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false
    else who = m.chat
    if (!who) return conn.reply(m.chat, `• *Example :* ${usedPrefix + command} @tag`, m)

    let user = global.db.data.users[who]
    let name = global.db.data.users[who].name
    let name2 = global.db.data.users[m.sender].name

    // Daftar URL gambar
    const kissImages = [
        'https://pomf2.lain.la/f/vptku23g.jpg',
        'https://pomf2.lain.la/f/khvnpod.jpg',
        'https://pomf2.lain.la/f/et5slqv.jpg',
        'https://pomf2.lain.la/f/yx2awyfg.jpg',
        'https://pomf2.lain.la/f/9rkj4xll.jpg',
        'https://pomf2.lain.la/f/efiq68s2.jpg',
        'https://pomf2.lain.la/f/76uvtq9e.jpg',
        'https://pomf2.lain.la/f/c165hogi.jpg',
        'https://pomf2.lain.la/f/6sa6700.jpg',
        'https://pomf2.lain.la/f/bnt5gw6.jpg',
        'https://pomf2.lain.la/f/fwhvkn5g.jpg', 
        'https://pomf2.lain.la/f/5nk36aru.jpg', 
        'https://pomf2.lain.la/f/h38dk0hv.jpg', 
        'https://pomf2.lain.la/f/gad27hpv.jpg', 
        // Tambahkan lebih banyak URL gambar sesuai kebutuhan
    ]

    // Fungsi untuk memilih gambar secara acak
    const pickRandom = (list) => {
        return list[Math.floor(Math.random() * list.length)]
    }

    // Mengambil gambar secara acak
    let randomImageUrl = pickRandom(kissImages)

    // Kirim gambar langsung tanpa memanggil JSON
    await conn.sendFile(m.chat, randomImageUrl, '', `*${name2}* Mencium *${name}*`, m)

    // Mengubah gambar menjadi sticker (opsional)
    try {
        let sticker = await sticker5(randomImageUrl)
        await conn.sendFile(m.chat, sticker, '', `*${name2}* Mencium *${name}* (sticker)`, m)
    } catch (error) {
        console.error('Error creating sticker:', error)
    }
}

handler.help = ['kiss *@tag*']
handler.tags = ['anime']
handler.command = /^(kiss)$/i
handler.group = true

module.exports = handler