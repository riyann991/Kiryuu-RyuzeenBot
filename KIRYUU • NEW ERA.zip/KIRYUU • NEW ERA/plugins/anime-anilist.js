const axios = require('axios');
const handler = async (m, { conn, text }) => {
  if (!text) {
    return await conn.sendMessage(
      m.chat,
      { text: "Contoh penggunaan: *.anilist one piece*" },
      { quoted: m }
    );
  }
  const query = `
    query ($search: String) {
      Media(search: $search, type: ANIME) {
        title {
          romaji
          english
        }
        description(asHtml: false)
        siteUrl
        coverImage {
          large
        }
      }
    }
  `;
  const variables = { search: text };

  try {
    const response = await axios.post('https://graphql.anilist.co', {
      query,
      variables,
    });

    const anime = response.data.data.Media;

    if (!anime) {
      return await conn.sendMessage(
        m.chat,
        { text: "Anime tidak ada." },
        { quoted: m }
      );
    }
    const title = anime.title.english || anime.title.romaji;
    const description = anime.description.replace(/<[^>]*>/g, ''); 
    await conn.sendMessage(
      m.chat,
      {
        image: { url: anime.coverImage.large },
        caption: `🔍 *Hasil Pencarian Anime*\n\n📌 *Judul*: ${title}\n📝 *Deskripsi*: ${description}\n🔗 *Link*: ${anime.siteUrl}`
      },
      { quoted: m }
    );
  } catch (error) {
    console.error('Error during Anilist search:', error);
    await conn.sendMessage(
      m.chat,
      { text: "❗ Gagal mengambil informasi anime." },
      { quoted: m }
    );
  }
};
handler.command = /^(anilist)$/i;
handler.tags = ['anime'];
handler.help = ['anilist nama anime'];
module.exports = handler;