let handler = async (m, { conn, text }) => {
    if (!text) {
        return conn.reply(m.chat, 'Main Nih Sama Kakek\nTaruhan Berapa?\nContoh: .zeus 2000', m);
    }

    let taruhan = parseInt(text);
    if (isNaN(taruhan) || taruhan <= 0) {
        return conn.reply(m.chat, 'Masukkan jumlah taruhan dengan benar.', m);
    }

    let user = global.db.data.users[m.sender];
    if (user.money < taruhan) {
        return conn.reply(m.chat, 'Uang kamu tidak cukup untuk melakukan taruhan.', m);
    }

    // Kurangi uang pengguna sesuai taruhan
    user.money -= taruhan;

    // Fungsi untuk menghasilkan simbol acak
    function generateSymbols() {
        const symbols = ['♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓', '⛎'];
        return Array.from({ length: 4 }, () => Array.from({ length: 6 }, () => symbols[Math.floor(Math.random() * symbols.length)]));
    }

    // Fungsi untuk memeriksa apakah ada kemenangan
    function checkWin(grid) {
        // Cek horizontal
        for (let i = 0; i < 4; i++) {
            for (let j = 0; j < 4; j++) {
                if (grid[i][j] === grid[i][j + 1] && grid[i][j] === grid[i][j + 2]) {
                    return true;
                }
            }
        }
        // Cek vertikal
        for (let j = 0; j < 6; j++) {
            for (let i = 0; i < 2; i++) {
                if (grid[i][j] === grid[i + 1][j] && grid[i][j] === grid[i + 2][j]) {
                    return true;
                }
            }
        }
        return false;
    }

    let symbols = generateSymbols();
    let win = checkWin(symbols);
    let resultText = `
You: @${m.sender.split('@')[0]}
Taruhan: ${taruhan}
Result: ${win ? 'Win' : 'Lose'}
Money: ${win ? `+${taruhan * 2}` : `-${taruhan}`}
    `.trim();

    if (win) {
        user.money += taruhan * 2;
    }

    let finalResult = `${resultText}\n${symbols.map(row => row.join('')).join('\n')}`;
    conn.reply(m.chat, finalResult, m);
};

handler.help = ['zeus <jumlah taruhan>'];
handler.tags = ['game'];
handler.command = /^zeus$/i;

module.exports = handler;