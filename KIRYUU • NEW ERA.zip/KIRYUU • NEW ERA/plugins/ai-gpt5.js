/*
*<>Gpt4o Realtime + Prompt<>*
SOURCE: https://whatsapp.com/channel/0029VaYVlVP9hXF9Ig83hJ3L
MAMPIR KESINI GUYS
*DONT DELETE MY WM, SAYA JANJI GA AKAN DELETE WM INI*
*/

const axios = require('axios');

async function askGpt4(prompt, query) {
  try {
    const apiKey = 'indradev';
    const url = `https://www.indranewbie.xyz/api/ai/gpt4o-prompt?query=${encodeURIComponent(query)}&prompt=${encodeURIComponent(prompt)}&apikey=${apiKey}`;
    
    const response = await axios.get(url);
    
    if (response.data.status) {
      return response.data.message;
    } else {
      throw "Maaf, terjadi kesalahan saat memproses permintaan.";
    }
  } catch (e) {
    console.error("Error processing GPT4o request:", e);
    throw "Maaf, terjadi kesalahan saat memproses permintaan Anda.";
  }
}

let handler = async (m, { conn, text, usedPrefix, command, args }) => {
  if (args.length >= 1) {
    text = args.slice(0).join(" ");
  } else if (m.quoted && m.quoted.text) {
    text = m.quoted.text;
  } else {
    throw "Input Teks";
  }

  const prompt = "namamu adalah Ucok dan kamu di ciptakan indradev saya asisten cerdas";
  
  await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

  try {
    const response = await askGpt4(prompt, text);
    await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });
    await conn.reply(m.chat, response, m);
  } catch (e) {
    await conn.reply(m.chat, e, m);
  }
}

handler.help = ["gpt5o *<text>*", "gpt5 *<text>*"];
handler.tags = ["ai"];
handler.command = ["gpt5", "gpt5o"];
handler.premium = true;
// https://whatsapp.com/channel/0029VaYVlVP9hXF9Ig83hJ3L
module.exports = handler;