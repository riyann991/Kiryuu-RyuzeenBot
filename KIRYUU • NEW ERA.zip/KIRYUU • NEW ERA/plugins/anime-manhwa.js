const fetch = require('node-fetch');

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) throw `Contoh Penggunaan:\n${usedPrefix}${command} Solo Leveling`;

    const query = args.join(" ");
    const apiUrl = `https://api.mangadex.org/manga?title=${encodeURIComponent(query)}&limit=1`;

    try {
        m.reply("🔍 Sedang mencari manhwa, harap tunggu...");

        const response = await fetch(apiUrl);
        if (!response.ok) throw `API mengembalikan status: ${response.status} ${response.statusText}`;

        const data = await response.json();

        if (!data || !data.data || data.data.length === 0) throw "Manhwa tidak ditemukan. Pastikan nama manhwa benar.";

        // Mengambil informasi manhwa pertama dari hasil pencarian
        const manhwa = data.data[0];
        const title = manhwa.attributes.title.en || "Judul tidak tersedia";
        const description = manhwa.attributes.description.en || "Deskripsi tidak tersedia";
        const status = manhwa.attributes.status || "Status tidak tersedia";
        const tags = manhwa.attributes.tags.map(tag => tag.attributes.name.en).join(", ") || "Tidak ada genre";

        // Mendapatkan cover image
        const coverResponse = await fetch(`https://api.mangadex.org/cover/${manhwa.relationships.find(rel => rel.type === "cover_art").id}`);
        const coverData = await coverResponse.json();
        const coverUrl = `https://uploads.mangadex.org/covers/${manhwa.id}/${coverData.data.attributes.fileName}`;

        // Menyusun pesan hasil
        const message = `
📖 *Judul*: ${title}
📚 *Status*: ${status}
🔖 *Genre*: ${tags}
📜 *Deskripsi*: ${description.slice(0, 500)}...
🔗 *Link*: https://mangadex.org/title/${manhwa.id}
        `;

        // Mengirim pesan dengan thumbnail jika tersedia
        await conn.sendMessage(
            m.chat,
            {
                image: { url: coverUrl },
                caption: message,
            },
            { quoted: m }
        );

    } catch (error) {
        console.error("Terjadi kesalahan saat mengakses API:", error);
        m.reply(`Terjadi kesalahan saat mencari manhwa. Coba lagi nanti atau gunakan kata kunci lain.`);
    }
};

handler.help = ['manhwa <judul>'];
handler.tags = ['anime'];
handler.command = /^(manhwa)$/i;

module.exports = handler;