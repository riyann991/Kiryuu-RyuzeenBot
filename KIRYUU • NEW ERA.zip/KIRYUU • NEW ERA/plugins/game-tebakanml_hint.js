/*
    made by adrianMD
    ch: https://whatsapp.com/channel/0029VaWXWTD8kyyOvgdf1o3x
    
    do not remove the watermark!! 
    
Thank you for using this code ^-^
*/

let handler = async (m, { conn }) => {
    conn.tebakanml = conn.tebakanml ? conn.tebakanml : {}
    let id = 'tebakanml-' + m.chat
    if (!(id in conn.tebakanml)) throw false
    let json = conn.tebakanml[id][1]
    m.reply('Clue : ' + '```' + json.jawaban.replace(/[AIUEOaiueo]/ig, '_') + '```' + '\n\n_*Jangan Balas Chat Ini Tapi Balas Soalnya*_')
}
handler.command = /^teml$/i
handler.limit = true
module.exports = handler