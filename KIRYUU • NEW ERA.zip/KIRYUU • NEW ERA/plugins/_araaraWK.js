const util = require("util");
const path = require("path");

let handler = async (m, { conn }) => {
    let kntl = `./vn/araara.mp3`
	await conn.sendFile(m.chat, kntl, "araara.mp3", null, m, true)
};
handler.customPrefix = /^(Ara ara|ara ara|Ara|ara)$/i;
handler.command = new RegExp();

module.exports = handler;