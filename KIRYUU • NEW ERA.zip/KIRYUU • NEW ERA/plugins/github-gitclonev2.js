/*
*<>GITCLONE, SUPPORT ALL URL<>*
SOURCE: https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
DON'T DELETE THIS WM!
HAPUS WM MANDUL 7 TURUNAN 
HAPUS WM=SDM RENDAH 
*KALO LU CONVERT APAPUN FITUR INI,WM JANGAN DIHAPUS!*
"aku janji tidak akan hapus wm ini"
JUM'AT, 06 NOVEMBER 07:23
*/

const fetch = require('node-fetch');
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
let regexRepo = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/([^\/:]+)(?:\/tree\/[^\/]+|\/blob\/[^\/]+)?(?:\/(.+))?/i;
let regexGist = /https:\/\/gist\.github\.com\/([^\/]+)\/([a-zA-Z0-9]+)/i;
let regexRawGitHub = /https:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/([^\/]+)\/(.+)/i;

// ©Mputz Don't Delete this wm
let handler = async (m, { args }) => {
    if (!args[0]) throw 'Link GitHub nya mana?';
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
    let isRepo = regexRepo.test(args[0]);
    let isGist = regexGist.test(args[0]);
    let isRawGitHub = regexRawGitHub.test(args[0]);
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
    if (!isRepo && !isGist && !isRawGitHub) throw 'Link salah!';
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
    if (isRepo) {
        let [, user, repo] = args[0].match(regexRepo) || [];
        repo = repo.replace(/.git$/, '');
        let url = `https://api.github.com/repos/${user}/${repo}/zipball`;
        let filename = (await fetch(url, { method: 'HEAD' })).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1];
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
        m.reply(`*Mohon tunggu, sedang mengirim repository..*`);
        await conn.sendMessage(m.chat, {
            document: { url: url },
            fileName: filename,
            mimetype: "application/zip",
            caption: `*Result From*: ${args}`
        }, { quoted: m });
    } else if (isGist) {
        let [, user, gistId] = args[0].match(regexGist) || [];
        let url = `https://gist.github.com/${user}/${gistId}/download`;
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
        m.reply(`*Mohon tunggu, sedang mengirim Gist..*`);
        await conn.sendMessage(m.chat, {
            document: { url: url },
            fileName: `${gistId}.zip`,
            mimetype: "application/zip",
            caption: `*Result From*: ${args}`
        }, { quoted: m });
    } else if (isRawGitHub) {
        let [, user, repo, branch, filepath] = args[0].match(regexRawGitHub) || [];
        let url = `https://raw.githubusercontent.com/${user}/${repo}/${branch}/${filepath}`;
        let filename = filepath.split('/').pop();
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
        m.reply(`*Mohon tunggu, sedang mengirim file dari RawGitHub..*`);
        await conn.sendMessage(m.chat, {
            document: { url: url },
            fileName: filename,
            mimetype: "application/octet-stream",
            caption: `*Result From*: ${args}`
        }, { quoted: m });
    }
};
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
handler.help = ['gitclonev2 <url>'];
handler.tags = ['github'];
handler.command = /gitclonev2/i;
handler.limit = true;
//wm https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
module.exports = handler;
/*
*<>GITCLONE, SUPPORT ALL URL<>*
SOURCE: https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
DON'T DELETE THIS WM!
HAPUS WM MANDUL 7 TURUNAN 
HAPUS WM=SDM RENDAH 
*KALO LU CONVERT APAPUN FITUR INI,WM JANGAN DIHAPUS!*
"aku janji tidak akan hapus wm ini"
JUM'AT, 06 NOVEMBER 07:23
*/