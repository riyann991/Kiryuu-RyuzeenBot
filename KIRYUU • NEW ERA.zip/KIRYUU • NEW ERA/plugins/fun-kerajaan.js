let handler = async (m, { conn, command, text, participants }) => {
    if (!text) return conn.reply(m.chat, 'Ketik Namanya!\n\nExample : .kerajaan budi', m);
    
    let who;
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid];
        who = member[Math.floor(Math.random() * member.length)];
    } else {
        let member = participants.map(u => u.id);
        who = member[Math.floor(Math.random() * member.length)];
    }

    // Mengambil anggota kerajaan lainnya
    let who2, who3, who4, who5, who6, who7, who8, who9, who10, who11;
    if (!m.isGroup) {
        let member = [m.sender, conn.user.jid];
        who2 = member[Math.floor(Math.random() * member.length)];
        who3 = member[Math.floor(Math.random() * member.length)];
        who4 = member[Math.floor(Math.random() * member.length)];
        who5 = member[Math.floor(Math.random() * member.length)];
        who6 = member[Math.floor(Math.random() * member.length)];
        who7 = member[Math.floor(Math.random() * member.length)];
        who8 = member[Math.floor(Math.random() * member.length)];
        who9 = member[Math.floor(Math.random() * member.length)];
        who10 = member[Math.floor(Math.random() * member.length)];
        who11 = member[Math.floor(Math.random() * member.length)];
    } else {
        let member = participants.map(u => u.id);
        who2 = member[Math.floor(Math.random() * member.length)];
        who3 = member[Math.floor(Math.random() * member.length)];
        who4 = member[Math.floor(Math.random() * member.length)];
        who5 = member[Math.floor(Math.random() * member.length)];
        who6 = member[Math.floor(Math.random() * member.length)];
        who7 = member[Math.floor(Math.random() * member.length)];
        who8 = member[Math.floor(Math.random() * member.length)];
        who9 = member[Math.floor(Math.random() * member.length)];
        who10 = member[Math.floor(Math.random() * member.length)];
        who11 = member[Math.floor(Math.random() * member.length)];
    }

    conn.reply(m.chat, `
〔 Kerajaan ${text} 〕

*Raja* : @${who.split`@`[0]}
*Ratu* : @${who2.split`@`[0]}
*Pangeran Pertama* : @${who3.split`@`[0]}
*Pangeran Kedua* : @${who4.split`@`[0]}
*Putri Pertama* : @${who5.split`@`[0]}
*Putri Kedua* : @${who6.split`@`[0]}
*Menteri* : @${who7.split`@`[0]}
*Kesatria Pertama* : @${who8.split`@`[0]}
*Kesatria Kedua* : @${who9.split`@`[0]}
*Warga* : @${who10.split`@`[0]}
*Pelayan* : @${who11.split`@`[0]}
`.trim(), m);
}

handler.help = ['kerajaan <nama>'];
handler.tags = ['fun'];
handler.command = /^kerajaan/i;
handler.group = true;

module.exports = handler;

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}