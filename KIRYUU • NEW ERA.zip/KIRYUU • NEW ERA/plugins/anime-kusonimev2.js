let fetch = require('node-fetch');
let fs = require('fs');
const axios = require('axios');
const FormData = require('form-data');
const cheerio = require('cheerio');

let handler = async (m, { conn, text, usedPrefix }) => {
    try {
        if (!text) return m.reply('Masukan anime yang ingin dicari!!\nContoh: .kusonime naruto');
        m.reply('Sedang mencari...'); // Ganti dengan variabel mess.wait jika ada
        let data = await scrapKusonime(text);
        let caption = `KUSONIMEV2 🦊
Title : ${data.title}
Views : ${data.view}
Type : ${data.type}
Season : ${data.season}
Status : ${data.status_anime}
Genre : ${data.genre}
Eps : ${data.total_episode}
Produser : ${data.producers}
Durasi : ${data.duration}
Score : ${data.score}
Rilis : ${data.released}
Sinopsis : ${data.description}
`;
        conn.sendMessage(m.chat, { image: { url: data.thumb }, caption: caption }, { quoted: m });
    } catch (e) {
        console.error(e); // Log error untuk debugging
        m.reply("Pencarian gagal.");
    }
}

handler.command = handler.help = ['kusonimev2'];
handler.tags = ['anime'];
handler.exp = 0;
handler.limit = true;
handler.premium = false;
handler.register = true;

module.exports = handler;

async function scrapKusonime(t) {
    return new Promise((resolve, reject) => {
        axios
            .get(`https://kusonime.com/?s=${t}&post_type=post`)
            .then(({ data }) => {
                const $ = cheerio.load(data);
                let links = [];
                $("div.content > h2 > a").each((_, element) => {
                    links.push($(element).attr("href"));
                });

                if (links.length === 0) {
                    return reject("Anime tidak ditemukan.");
                }

                axios.get(links[0]).then(({ data }) => {
                    const $ = cheerio.load(data);
                    let title = $('div[class="post-thumb"] > h1').text();
                    let thumb = $('div[class="post-thumb"] > img').attr("src");
                    let info = $('div.info > p').map((_, element) => $(element).text().split(":")[1]?.trim()).get();

                    let result = {
                        title: title,
                        thumb: thumb,
                        view: info[0],
                        genre: info[1],
                        season: info[2],
                        producers: info[3],
                        type: info[4],
                        status_anime: info[5],
                        total_episode: info[6],
                        score: info[7],
                        duration: info[8],
                        released: info[9],
                        description: $('div.lexot > p:nth-child(3)').text(),
                    };

                    resolve(result);
                }).catch(reject);
            }).catch(reject);
    });
}